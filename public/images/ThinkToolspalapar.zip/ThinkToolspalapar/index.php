<?php 

    $names = array("Computer", "Laptops", "Accesories");

    $count = 0;

    while($count < count($names)){
        echo "<p>$names[$count]</p>";
        $count++;
    }

?>